# -*- coding: utf-8 -*-
"""

This file is used to match SMILES in dataset file 
with 3D geometry (xTB, GFN0 level) files.

@author: Li-Cheng Xu
"""




import numpy as np
import pandas as pd

geoms_file_smi = pd.read_csv('./geom_smi_map.csv')

tot_smiles,tot_files = geoms_file_smi['smiles'].to_list(),geoms_file_smi['file'].to_list()
tot_smiles = [tmp_item.split()[0] for tmp_item in tot_smiles]

smi2file_map = {tmp_smi:tmp_file for tmp_smi,tmp_file in zip(tot_smiles,tot_files)}

dataset = pd.read_csv('./aho_dataset.csv',index_col=0)

re_smi = dataset['Reactant SMILES'].to_list()
pr_smi = dataset['Product SMILES'].to_list()
sol_smi = dataset['Solvent SMILES'].to_list()
cat_smi_ = dataset['Catalyst SMILES(RDKit)'].to_list()
lig_smi_ = dataset['Ligand SMILES'].to_list()
cat_smi = []
lig_smi = []
dihedral_tag = dataset['Dihedral Tag'].to_list()
for i in range(len(cat_smi_)):
    dih_tag = dihedral_tag[i]
    if not isinstance(dih_tag,str) and np.isnan(dih_tag):
        cat_smi.append(cat_smi_[i])
        lig_smi.append(lig_smi_[i])
    else:
        dih_tag_list = dih_tag.split(',')
        if len(dih_tag_list) == 1:
            l_smi = lig_smi_[i] + '//' + dih_tag_list[0]
            c_smi = cat_smi_[i] + '//' + dih_tag_list[0]
        else:
            l_smi = lig_smi_[i] + '//' + dih_tag_list[0] + '//' + dih_tag_list[1]
            c_smi = cat_smi_[i] + '//' + dih_tag_list[0] + '//' + dih_tag_list[1]

        cat_smi.append(c_smi)
        lig_smi.append(l_smi)
        
re_files = [smi2file_map[smi] for smi in re_smi]
pr_files = [smi2file_map[smi] for smi in pr_smi]
sol_files = [smi2file_map[smi] for smi in sol_smi]
cat_files = [smi2file_map[smi] for smi in cat_smi]
lig_files = [smi2file_map[smi] for smi in lig_smi]